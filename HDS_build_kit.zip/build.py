import zipfile, struct, hashlib, base64, subprocess, os
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography import x509

SRC='/mnt/user-data/uploads/newp.apk'; ROOT=os.environ.get('ROOT','/tmp/a')
changed={}

# key + cert
if not os.path.exists('key.pem'):
    subprocess.run('openssl req -x509 -newkey rsa:2048 -nodes -keyout key.pem -out cert.pem -days 10000 -subj "/CN=HDS Player/O=HDS" -sha256',shell=True,check=True,capture_output=True)

zin=zipfile.ZipFile(SRC)
entries=[]
for zi in zin.infolist():
    n=zi.filename
    if n.startswith('META-INF/') and (n.endswith('.MF') or n.endswith('.SF') or n.endswith('.RSA') or n.endswith('.DSA') or n.endswith('.EC')): continue
    if n.endswith('/'): continue
    if n.startswith('assets/www/') and not os.path.exists(ROOT+'/'+n): continue
    if os.environ.get('ARM32') and (n.startswith('lib/arm64-v8a/') or n.startswith('lib/x86/') or n.startswith('lib/x86_64/')): continue
    if os.environ.get('ARM64') and (n.startswith('lib/armeabi-v7a/') or n.startswith('lib/x86/') or n.startswith('lib/x86_64/')): continue
    data=open(ROOT+'/'+n,'rb').read() if os.path.exists(ROOT+'/'+n) else zin.read(n)
    entries.append((zi,data))

names={zi.filename for zi,_ in entries}
for dp,dn,fn in os.walk(ROOT+'/assets/www'):
    for f in fn:
        full=os.path.join(dp,f); n=os.path.relpath(full,ROOT).replace(os.sep,'/')
        if n in names: continue
        zi=zipfile.ZipInfo(n,(1980,1,1,0,0,0)); zi.compress_type=zipfile.ZIP_DEFLATED; zi.external_attr=0
        entries.append((zi,open(full,'rb').read()))

def wrap(line):
    b=line.encode('utf-8'); out=[]
    out.append(b[:70]); b=b[70:]
    while b: out.append(b' '+b[:69]); b=b[69:]
    return b'\r\n'.join(out)+b'\r\n'

mf=b'Manifest-Version: 1.0\r\nCreated-By: 1.0 (Android)\r\n\r\n'
sections=[]
for zi,data in entries:
    sec=wrap('Name: '+zi.filename)+wrap('SHA-256-Digest: '+base64.b64encode(hashlib.sha256(data).digest()).decode())+b'\r\n'
    sections.append((zi.filename,sec)); mf+=sec
sf=b'Signature-Version: 1.0\r\nCreated-By: 1.0 (Android)\r\n'+wrap('SHA-256-Digest-Manifest: '+base64.b64encode(hashlib.sha256(mf).digest()).decode())+b'X-Android-APK-Signed: 2\r\n\r\n'
for n,sec in sections:
    sf+=wrap('Name: '+n)+wrap('SHA-256-Digest: '+base64.b64encode(hashlib.sha256(sec).digest()).decode())+b'\r\n'
open('CERT.SF','wb').write(sf)
subprocess.run('openssl smime -sign -binary -noattr -in CERT.SF -signer cert.pem -inkey key.pem -outform DER -md sha256 -out CERT.RSA',shell=True,check=True)
rsa=open('CERT.RSA','rb').read()

out_path='unsigned.apk'
zo=zipfile.ZipFile(out_path,'w')
def put(name,data,ctype,dt=(1980,1,1,0,0,0),ext_attr=0):
    zi=zipfile.ZipInfo(name,dt); zi.compress_type=ctype; zi.external_attr=ext_attr; zi.create_system=0
    if ctype==zipfile.ZIP_STORED:
        align=4096 if name.endswith('.so') else 4
        off=zo.fp.tell(); hdr=30+len(name.encode())
        pad=(-(off+hdr))%align
        if pad:
            if pad<6: pad+=align
            zi.extra=struct.pack('<HHH',0xD935,pad-4,align)+b'\0'*(pad-6)
    zo.writestr(zi,data)
put('META-INF/MANIFEST.MF',mf,zipfile.ZIP_DEFLATED)
put('META-INF/CERT.SF',sf,zipfile.ZIP_DEFLATED)
put('META-INF/CERT.RSA',rsa,zipfile.ZIP_DEFLATED)
for zi,data in entries:
    put(zi.filename,data,zi.compress_type,zi.date_time,zi.external_attr)
zo.close()

# ---- v2 signature ----
apk=open(out_path,'rb').read()
eocd=apk.rfind(b'PK\x05\x06'); cd_off=struct.unpack('<I',apk[eocd+16:eocd+20])[0]
s1=apk[:cd_off]; s3=apk[eocd:]; s2=apk[cd_off:eocd]
def chunks(b):
    for i in range(0,len(b),1<<20): yield b[i:i+(1<<20)]
digs=[]
for sec in (s1,s2,s3):
    for c in chunks(sec): digs.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(c))+c).digest())
top=hashlib.sha256(b'\x5a'+struct.pack('<I',len(digs))+b''.join(digs)).digest()
key=serialization.load_pem_private_key(open('key.pem','rb').read(),None)
cert=x509.load_pem_x509_certificate(open('cert.pem','rb').read())
cder=cert.public_bytes(serialization.Encoding.DER)
pub=cert.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
L=lambda b:struct.pack('<I',len(b))+b
dig_entry=L(struct.pack('<I',0x0103)+L(top))
signed=L(dig_entry)+L(L(cder))+L(b'')
sig=key.sign(signed,padding.PKCS1v15(),hashes.SHA256())
sigs=L(L(struct.pack('<I',0x0103)+L(sig)))
signer=L(signed)+sigs+L(pub)
value=L(L(signer))
pair=struct.pack('<Q',4+len(value))+struct.pack('<I',0x7109871a)+value
blk_size=len(pair)+8+16
block=struct.pack('<Q',blk_size)+pair+struct.pack('<Q',blk_size)+b'APK Sig Block 42'
new_eocd=s3[:16]+struct.pack('<I',cd_off+len(block))+s3[20:]
open(os.environ.get('OUT','/mnt/user-data/outputs/HDS_NewPlayer_v14.apk'),'wb').write(s1+block+s2+new_eocd)
print('built',len(s1+block+s2+new_eocd))

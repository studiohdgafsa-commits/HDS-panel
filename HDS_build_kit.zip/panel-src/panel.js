(function () {
  "use strict";
  var $ = function (i) { return document.getElementById(i); };
  var enc = new TextEncoder(), dec = new TextDecoder();
  var GHD = { u: "studiohdgafsa-commits", r: "HDS-panel", b: "main", f: "config.json" };
  var TILES = [["settings", "الإعدادات · Paramètres"], ["live", "قنوات مباشرة · Live TV"], ["movies", "أفلام · Movies"], ["radio", "راديو · Radio"], ["series", "مسلسلات · Series"], ["kids", "أطفال · Kids"], ["quran", "قرآن كريم · Coran"], ["expiry", "صلاحية السيرفر"], ["edit", "ترتيب القنوات"], ["prayer", "مواقيت الصلاة"], ["update", "تحميل التطبيقات · App Downloader"], ["news", "جديد المنصة · HDS News"], ["sport", "دليل الرياضة · HDS Sport"], ["games", "ألعاب · Games"]];
  var SOCS = [["tg", "تيليغرام"], ["wa", "واتساب"], ["tt", "تيك توك"], ["fb", "فيسبوك"], ["ig", "إنستغرام"], ["yt", "يوتيوب"]];
  var SLOTS = ["H", "N", "S", "E", "M", "A", "P", "MT", "B"];
  var DEF = {
    servers: [{ name: "HDS.H", url: "http://plus-577sghag.lol" }, { name: "HDS.N", url: "http://until56972.wd.business-cloud-neo.com" }, { name: "HDS.E", url: "http://139730421906.elg-26.com:80" }, { name: "HDS.M", url: "http://b9999.xyz" }],
    whatsapp: "21629575199", waLabel: "استفسار", facebook: "https://www.facebook.com/share/g/1Mx4Htun2B/", fbLabel: "جديد المنصة",
    telegram: "https://t.me/+TQgs42z0nsA5MzY8", tiktok: "https://www.tiktok.com/@hdsmartservices", instagram: "https://www.instagram.com/hds96099?srtk=MWg1d3prYmgzZzJrag==", youtube: "https://youtube.com/@hds-tube?si=F7zdcgVxE2LqM0h-", gamesUrl: "https://www.google.fr/logos/2010/pacman10-i.html",
    updateUrl: "https://hds-app-store.hds-8cc.workers.dev", newsUrl: "", welcome: "مرحبا بكم في عالم الفرجة HDS", intro: true, city: "Tunis", country: "Tunisia",
    hide: [], socOff: [], notice: "", maint: { on: false, text: "" }, bg: "hex", bgUrl: "", dim: 75, menu: "glass"
  };
  var S = null, PASS = null, USER = "HDS", dirty = false, lastSeq = 0, failN = 0, idleT = null, built = false, tt = null, hiddenAt = 0;
  if (window.top !== window.self) { document.documentElement.innerHTML = ""; return; }
  function lockInfo() { try { return JSON.parse(localStorage.getItem("hdsLock") || "{}"); } catch (e) { return {}; } }
  function lockFail() { var i = lockInfo(), n = (i.n || 0) + 1, until = n >= 5 ? Date.now() + Math.min(Math.pow(2, n - 5) * 60000, 3600000) : 0; localStorage.setItem("hdsLock", JSON.stringify({ n: n, until: until })); }
  function lockClear() { localStorage.removeItem("hdsLock"); }

  function toast(m, bad) { var t = $("toast"); t.textContent = m; t.className = "show" + (bad ? " bad" : ""); clearTimeout(tt); tt = setTimeout(function () { t.className = ""; }, bad ? 5200 : 3200); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function b64(buf) { var a = new Uint8Array(buf), s = ""; for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s); }
  function unb64(s) { var r = atob(String(s).replace(/\s/g, "")), a = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) a[i] = r.charCodeAt(i); return a; }
  function kdf(pass, salt) {
    return crypto.subtle.importKey("raw", enc.encode(pass), "PBKDF2", false, ["deriveKey"]).then(function (m) {
      return crypto.subtle.deriveKey({ name: "PBKDF2", salt: salt, iterations: 310000, hash: "SHA-256" }, m, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
    });
  }
  function seal(pass, obj, pub) {
    var salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
    return kdf(pass, salt).then(function (k) { return crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, k, enc.encode(JSON.stringify(obj))); })
      .then(function (ct) { return { v: 1, s: b64(salt), i: b64(iv), d: b64(ct), pub: pub }; });
  }
  function open(pass, v) {
    return kdf(pass, unb64(v.s)).then(function (k) { return crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(v.i) }, k, unb64(v.d)); })
      .then(function (pt) { return JSON.parse(dec.decode(pt)); });
  }
  function lsv() { try { return JSON.parse(localStorage.getItem("hdsVault2") || "null"); } catch (e) { return null; } }
  function persist() { return seal(PASS, { k: S.k, pub: S.pub, t: S.t || "" }, S.pub).then(function (v) { localStorage.setItem("hdsVault2", JSON.stringify(v)); }); }

  /* ---------- connexion ---------- */
  var AR = { "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9", "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9" };
  function normPw(p) { var t = String(p); try { t = t.normalize("NFKC"); } catch (e) { } return t.replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g, "").replace(/[٠-٩۰-۹]/g, function (c) { return AR[c] || c; }).trim(); }
  function pwVariants(p) { var a = [p], t = p.trim(), n = normPw(p); if (a.indexOf(t) < 0) a.push(t); if (a.indexOf(n) < 0) a.push(n); return a; }
  async function openAny(user, pw, v) {
    var vs = pwVariants(pw), lastErr = null;
    for (var i = 0; i < vs.length; i++) { try { var o = await open(user + "|" + vs[i], v); if (o && o.k) return { obj: o, pass: user + "|" + vs[i] }; } catch (e) { lastErr = e; } }
    throw lastErr || new Error("bad");
  }
  function lgErr(m) { $("lgErr").textContent = m || ""; }
  async function login() {
    var u = $("lgUser").value.trim().toUpperCase(), p = $("lgPass").value;
    if (!u || !p) { lgErr("أدخل اسم المستخدم وكلمة السر"); return; }
    if (!(window.crypto && crypto.subtle)) { lgErr("هذا المتصفح لا يدعم التشفير. افتح اللوحة عبر Chrome."); return; }
    var li = lockInfo(); if (li.until && li.until > Date.now()) { lgErr("محاولات كثيرة. انتظر " + Math.ceil((li.until - Date.now()) / 60000) + " دقيقة ثم أعد المحاولة."); return; }
    lgErr(""); $("lgGo").disabled = true;
    if (failN) await sleep(Math.min(failN, 6) * 900);
    var vbytes = 0;
    try {
      var v = lsv(), local = !!v, got;
      if (!v) {
        var r = await fetch("vault.json?t=" + Date.now(), { cache: "no-store" });
        if (!r.ok) { var er = new Error("novault"); er.code = r.status; throw er; }
        var txt = await r.text(); vbytes = txt.length; v = JSON.parse(txt);
      }
      try { got = await openAny(u, p, v); } catch (e) { var er2 = new Error(e && e.name === "OperationError" ? "bad" : "tech"); er2.orig = e; throw er2; }
      S = got.obj; PASS = got.pass; USER = u; failN = 0; lockClear();
      if (!local) await persist();
      $("lgPass").value = ""; $("login").classList.add("hidden"); $("app").classList.remove("hidden");
      init();
    } catch (e) {
      failN++; if (e.message !== "novault") lockFail();
      if (e.message === "novault") lgErr("E1: ملف vault.json غير موجود في المستودع (الرمز " + (e.code || "?") + "). تأكد من رفعه ثم أعد المحاولة بعد دقيقة.");
      else if (e.message === "tech") lgErr("E3: خطأ تقني في المتصفح: " + ((e.orig && (e.orig.name + " " + e.orig.message)) || "") + " — جرّب متصفح Chrome.");
      else lgErr("E2: بيانات الدخول غير صحيحة" + (vbytes ? " (حجم vault.json = " + vbytes + " بايت، والأصلي 717)" : ""));
    }
    $("lgGo").disabled = false;
  }
  function lock() {
    S = null; PASS = null; clearTimeout(idleT);
    $("app").classList.add("hidden"); $("login").classList.remove("hidden"); $("lgPass").value = ""; $("tok").value = "";
  }
  function idle() { clearTimeout(idleT); idleT = setTimeout(function () { if (S) { lock(); lgErr("أُغلقت الجلسة لعدم النشاط"); } }, 15 * 60 * 1000); }

  /* ---------- interface ---------- */
  function go(t) {
    [].forEach.call(document.querySelectorAll("#tabs button"), function (b) { b.classList.toggle("on", b.getAttribute("data-t") === t); });
    [].forEach.call(document.querySelectorAll(".pane"), function (p) { p.classList.toggle("on", p.id === "p-" + t); });
    window.scrollTo(0, 0);
  }
  function sw(id, label) {
    var l = document.createElement("label"); l.className = "sw";
    var i = document.createElement("input"); i.type = "checkbox"; i.id = id; i.checked = true;
    var k = document.createElement("i"), s = document.createElement("span"); s.textContent = label;
    l.appendChild(i); l.appendChild(k); l.appendChild(s); return l;
  }
  function build() {
    if (built) return; built = true;
    SLOTS.forEach(function (k) {
      var d = document.createElement("div"); d.className = "slot";
      var n = document.createElement("div"); n.className = "nm"; n.textContent = "HDS." + k;
      var inp = document.createElement("input"); inp.type = "url"; inp.id = "sv-" + k; inp.className = "ltr"; inp.placeholder = "http://server:port"; inp.autocapitalize = "off";
      var st = document.createElement("span"); st.className = "dot"; st.id = "sd-" + k;
      d.appendChild(n); d.appendChild(inp); d.appendChild(st); $("slots").appendChild(d);
      inp.addEventListener("input", function () { st.className = "dot" + (/^https?:\/\/\S+$/i.test(inp.value.trim()) ? " ok" : ""); });
    });
    TILES.forEach(function (t) { $("tiles").appendChild(sw("tl-" + t[0], t[1])); });
    SOCS.forEach(function (t) { $("socs").appendChild(sw("sc-" + t[0], t[1])); });
    [].forEach.call(document.querySelectorAll("#tabs button"), function (b) { b.addEventListener("click", function () { go(b.getAttribute("data-t")); }); });
    document.addEventListener("input", function (e) { if (e.target && e.target.closest && e.target.closest("main") && !/^(pw|tok|gh)/.test(e.target.id)) { setDirty(true); preview(); } });
    document.addEventListener("change", function (e) { if (e.target && e.target.closest && e.target.closest("main") && /^(tl|sc|introOn|mOn|bg|menu)/.test(e.target.id)) { setDirty(true); preview(); } });
  }
  function setDirty(v) { dirty = v; var d = $("dirty"); d.textContent = v ? "لديك تغييرات غير محفوظة" : ""; d.className = "st" + (v ? " dirty" : ""); }
  function ghTxt() { var ok = !!(S && S.t); $("ghState").firstChild.className = "dot " + (ok ? "ok" : "no"); $("ghTxt").textContent = ok ? "متصل بـ GitHub" : "أضف رمز GitHub"; $("tokNote").classList.toggle("hidden", ok); }
  function init() {
    build(); idle();
    var g = {}; try { g = JSON.parse(localStorage.getItem("hdsGh2") || "{}"); } catch (e) { }
    $("ghU").value = g.u || GHD.u; $("ghR").value = g.r || GHD.r; $("ghB").value = g.b || GHD.b; $("ghF").value = g.f || GHD.f;
    $("pubk").textContent = JSON.stringify(S.pub);
    ghTxt(); go(S.t ? "srv" : "sec"); loadCfg(true);
  }
  function gh() { var g = { u: $("ghU").value.trim() || GHD.u, r: $("ghR").value.trim() || GHD.r, b: $("ghB").value.trim() || GHD.b, f: $("ghF").value.trim() || GHD.f }; localStorage.setItem("hdsGh2", JSON.stringify(g)); return g; }
  function clean(x, n) { return String(x == null ? "" : x).replace(/[<>"'`&\\]/g, "").trim().slice(0, n); }

  function fill(c) {
    c = Object.assign({}, DEF, c || {});
    var by = {}; (c.servers || []).forEach(function (s) { by[String(s.name).toUpperCase()] = s.url; });
    SLOTS.forEach(function (k) { var i = $("sv-" + k); i.value = by["HDS." + k] || ""; i.dispatchEvent(new Event("input")); });
    TILES.forEach(function (t) { $("tl-" + t[0]).checked = (c.hide || []).indexOf(t[0]) < 0; });
    SOCS.forEach(function (t) { $("sc-" + t[0]).checked = (c.socOff || []).indexOf(t[0]) < 0; });
    $("notice").value = c.notice || ""; $("wa").value = c.whatsapp || ""; $("waL").value = c.waLabel || ""; $("fbL").value = c.fbLabel || "";
    $("fb").value = c.facebook || ""; $("ig").value = c.instagram || ""; $("tt").value = c.tiktok || ""; $("tg").value = c.telegram || ""; $("yt").value = c.youtube || "";
    $("news").value = c.newsUrl || ""; $("upd").value = c.updateUrl || ""; $("gm").value = c.gamesUrl || ""; $("welcome").value = c.welcome || ""; $("introOn").checked = c.intro !== false;
    $("bg").value = c.bg || "hex"; $("bgUrl").value = c.bgUrl || ""; $("dim").value = c.dim || 75; $("dimV").textContent = $("dim").value; $("menu").value = c.menu || "glass"; $("city").value = c.city || ""; $("country").value = c.country || ""; $("mOn").checked = !!(c.maint && c.maint.on); $("mTxt").value = (c.maint && c.maint.text) || "";
    setDirty(false); preview();
  }
  function collect() {
    var servers = [];
    SLOTS.forEach(function (k) {
      var v = $("sv-" + k).value.trim().replace(/\/+$/, "");
      if (v) { if (!/^https?:\/\/[^\s<>"'`]+$/i.test(v)) throw new Error("عنوان السيرفر HDS." + k + " يجب أن يبدأ بـ http:// أو https://"); servers.push({ name: "HDS." + k, url: v }); }
    });
    var wa = $("wa").value.replace(/\D/g, ""); if (wa && (wa.length < 8 || wa.length > 15)) throw new Error("رقم الواتساب غير صحيح");
    function link(id, label, re) { var v = $(id).value.trim(); if (!v) return ""; if (!/^https:\/\/[^\s<>"'`]+$/i.test(v) || (re && !re.test(v))) throw new Error("رابط " + label + " غير صحيح (يجب أن يبدأ بـ https://" + (re ? " ويكون من الموقع نفسه" : "") + ")"); return v; }
    var hide = [], socOff = [];
    TILES.forEach(function (t) { if (!$("tl-" + t[0]).checked) hide.push(t[0]); });
    SOCS.forEach(function (t) { if (!$("sc-" + t[0]).checked) socOff.push(t[0]); });
    return {
      seq: 0, servers: servers, whatsapp: wa, waLabel: clean($("waL").value, 30), facebook: link("fb", "فيسبوك", /^https:\/\/(www\.|m\.|web\.)?(facebook\.com|fb\.com|fb\.me)\//i), fbLabel: clean($("fbL").value, 30),
      telegram: link("tg", "تيليغرام", /^https:\/\/(t\.me|telegram\.me)\//i), tiktok: link("tt", "تيك توك", /^https:\/\/(www\.)?tiktok\.com\//i), instagram: link("ig", "إنستغرام", /^https:\/\/(www\.)?instagram\.com\//i), youtube: link("yt", "يوتيوب", /^https:\/\/(www\.|m\.)?(youtube\.com|youtu\.be)\//i),
      updateUrl: link("upd", "التحميل"), gamesUrl: link("gm", "الألعاب"), newsUrl: link("news", "جديد المنصة"), welcome: clean($("welcome").value, 120), intro: $("introOn").checked,
      city: clean($("city").value, 40), country: clean($("country").value, 40), hide: hide, socOff: socOff, bg: $("bg").value, bgUrl: link("bgUrl", "الخلفية"), dim: +$("dim").value || 75, menu: $("menu").value, notice: clean($("notice").value, 200), maint: { on: $("mOn").checked, text: clean($("mTxt").value, 240) }
    };
  }
  var pvT = null;
  function preview() { clearTimeout(pvT); pvT = setTimeout(function () { try { $("prev").textContent = JSON.stringify(collect(), null, 2); } catch (e) { $("prev").textContent = e.message; } }, 150); }


  /* ---------- appareils (MAC) ---------- */
  var DEVS = [];
  function normMac(x) { var h = String(x).toUpperCase().replace(/[^0-9A-F]/g, ""); return h.length === 12 ? h.match(/../g).join(":") : ""; }
  function normKey(x) { var k = String(x).toUpperCase().replace(/[^A-Z2-9]/g, ""); return k.length === 8 ? k : ""; }
  function hex(buf) { var a = new Uint8Array(buf), s = ""; for (var i = 0; i < a.length; i++) s += ("0" + a[i].toString(16)).slice(-2); return s; }
  async function sha24(m) { return hex(await crypto.subtle.digest("SHA-256", enc.encode(m))).slice(0, 24); }
  async function encDev(d) {
    var salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
    var base = await crypto.subtle.importKey("raw", enc.encode(d.mac + "|" + d.key), "PBKDF2", false, ["deriveKey"]);
    var k = await crypto.subtle.deriveKey({ name: "PBKDF2", salt: salt, iterations: 150000, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt"]);
    var ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, k, enc.encode(JSON.stringify({ u: d.url, n: d.user, p: d.pass, l: d.label })));
    return { h: await sha24(d.mac), s: b64(salt), i: b64(iv), d: b64(ct) };
  }
  async function dvKey() { var h = await crypto.subtle.digest("SHA-256", enc.encode("hds-dv|" + S.k.d)); return crypto.subtle.importKey("raw", h, "AES-GCM", false, ["encrypt", "decrypt"]); }
  async function sealDevs() { var iv = crypto.getRandomValues(new Uint8Array(12)), ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, await dvKey(), enc.encode(JSON.stringify(DEVS))); return { i: b64(iv), d: b64(ct) }; }
  async function openDevs(dv) {
    DEVS = [];
    if (dv && dv.i && dv.d) { try { DEVS = JSON.parse(dec.decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(dv.i) }, await dvKey(), unb64(dv.d)))); } catch (e) { DEVS = []; } }
    renderDevs();
  }
  function renderDevs() {
    var box = $("devList"); box.innerHTML = ""; $("dCount").textContent = DEVS.length ? "(" + DEVS.length + ")" : "";
    if (!DEVS.length) { var p = document.createElement("p"); p.className = "h"; p.textContent = "لا توجد أجهزة مضافة بعد."; box.appendChild(p); return; }
    DEVS.forEach(function (d, i) {
      var r = document.createElement("div"); r.className = "dv";
      var l = document.createElement("span"); l.className = "l"; l.textContent = d.label || "(بدون اسم)";
      var m = document.createElement("span"); m.className = "m"; m.textContent = d.mac;
      var u = document.createElement("span"); u.className = "u"; u.textContent = d.url;
      var e = document.createElement("button"); e.type = "button"; e.className = "ghost"; e.textContent = "تعديل";
      e.addEventListener("click", function () { $("dMac").value = d.mac; $("dKey").value = d.key; $("dLabel").value = d.label || ""; $("dUrl").value = d.url; $("dUser").value = d.user; $("dPass").value = d.pass; window.scrollTo(0, 0); });
      var x = document.createElement("button"); x.type = "button"; x.className = "warn"; x.textContent = "حذف";
      x.addEventListener("click", function () { if (window.confirm("حذف هذا الجهاز؟")) { DEVS.splice(i, 1); renderDevs(); setDirty(true); } });
      r.appendChild(l); r.appendChild(m); r.appendChild(u); r.appendChild(e); r.appendChild(x); box.appendChild(r);
    });
  }
  function addDev() {
    var mac = normMac($("dMac").value), key = normKey($("dKey").value), url = $("dUrl").value.trim().replace(/\/+$/, ""), user = $("dUser").value.trim(), pass = $("dPass").value;
    if (!mac) { toast("عنوان MAC غير صحيح (12 خانة سداسية)", true); return; }
    if (!key) { toast("Device Key غير صحيح (8 أحرف/أرقام)", true); return; }
    if (!/^https?:\/\/[^\s<>"'`]+$/i.test(url)) { toast("عنوان السيرفر يجب أن يبدأ بـ http:// أو https://", true); return; }
    if (!user || !pass) { toast("أدخل اسم المستخدم وكلمة السر", true); return; }
    var d = { mac: mac, key: key, label: clean($("dLabel").value, 40), url: url, user: user, pass: pass };
    var ix = -1; DEVS.forEach(function (x, i) { if (x.mac === mac) ix = i; });
    if (ix >= 0) DEVS[ix] = d; else DEVS.push(d);
    ["dMac", "dKey", "dLabel", "dUrl", "dUser", "dPass"].forEach(function (id) { $(id).value = ""; });
    renderDevs(); setDirty(true); toast("أُضيف الجهاز. اضغط «حفظ ونشر» لتطبيقه.");
  }
  async function withDevices(cfg) {
    for (var i = 0; i < DEVS.length; i++) { if (!DEVS[i].e) { toast("جارٍ تشفير الجهاز " + (i + 1) + " من " + DEVS.length + "…"); DEVS[i].e = await encDev(DEVS[i]); } }
    cfg.devices = DEVS.map(function (d) { return d.e; }); cfg.dv = await sealDevs(); return cfg;
  }

  /* ---------- GitHub ---------- */
  function api(g, path) { return "https://api.github.com/repos/" + encodeURIComponent(g.u) + "/" + encodeURIComponent(g.r) + "/contents/" + path.split("/").map(encodeURIComponent).join("/"); }
  function hdr(json) { var h = { "Accept": "application/vnd.github+json" }; if (S && S.t) h["Authorization"] = "Bearer " + S.t; if (json) h["Content-Type"] = "application/json"; return h; }
  async function loadCfg(quiet) {
    var g = gh();
    try {
      var r = await fetch(api(g, g.f) + "?ref=" + encodeURIComponent(g.b) + "&t=" + Date.now(), { headers: hdr(false), cache: "no-store" });
      if (r.status === 404) { fill(DEF); if (!quiet) toast("لا يوجد ملف إعدادات بعد. عُرضت القيم الافتراضية."); return; }
      if (r.status === 401 || r.status === 403) throw new Error("الرمز غير صالح أو لا يملك الصلاحية (" + r.status + ")");
      if (!r.ok) throw new Error("تعذّر التحميل (" + r.status + ")");
      var j = await r.json(), env = JSON.parse(dec.decode(unb64(j.content))), cfg = env.payload ? JSON.parse(env.payload) : env;
      lastSeq = +cfg.seq || 0; fill(cfg); await openDevs(cfg.dv); if (!quiet) toast("تم تحميل الإعدادات الحالية");
    } catch (e) { fill(DEF); DEVS = []; renderDevs(); toast(e.message || "تعذّر التحميل", true); }
  }
  async function sign(text) {
    var key = await crypto.subtle.importKey("jwk", S.k, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
    return b64(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, enc.encode(text)));
  }
  async function putFile(g, path, text, msg) {
    var url = api(g, path), sha = null;
    var r = await fetch(url + "?ref=" + encodeURIComponent(g.b) + "&t=" + Date.now(), { headers: hdr(false), cache: "no-store" });
    if (r.ok) sha = (await r.json()).sha; else if (r.status !== 404) throw new Error("تعذّر الوصول إلى المستودع (" + r.status + ") — تحقق من الرمز");
    var body = { message: msg, content: b64(enc.encode(text)), branch: g.b }; if (sha) body.sha = sha;
    var w = await fetch(url, { method: "PUT", headers: hdr(true), body: JSON.stringify(body) });
    if (!w.ok) throw new Error("فشل الحفظ (" + w.status + ") — تأكد أن الرمز يملك Contents: Read and write");
  }
  async function save() {
    if (!S) return;
    if (!S.t) { go("sec"); toast("أضف رمز GitHub أولاً", true); return; }
    var cfg; try { cfg = collect(); } catch (e) { toast(e.message, true); return; }
    $("save").disabled = true;
    try {
      cfg.seq = Math.max(Date.now(), lastSeq + 1); cfg = await withDevices(cfg);
      var payload = JSON.stringify(cfg), sig = await sign(payload), g = gh();
      await putFile(g, g.f, JSON.stringify({ payload: payload, sig: sig }, null, 2), "تحديث الإعدادات من اللوحة");
      lastSeq = cfg.seq; setDirty(false); toast("تم الحفظ والنشر ✓ يصل التغيير إلى التطبيق خلال دقائق");
    } catch (e) { toast(e.message || "فشل الحفظ", true); }
    $("save").disabled = false;
  }
  async function download() {
    if (!S) return; var cfg; try { cfg = collect(); } catch (e) { toast(e.message, true); return; }
    cfg.seq = Math.max(Date.now(), lastSeq + 1); cfg = await withDevices(cfg);
    var payload = JSON.stringify(cfg), sig = await sign(payload);
    var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify({ payload: payload, sig: sig }, null, 2)], { type: "application/json" })); a.download = "config.json"; a.click();
  }
  async function saveToken() {
    if (!S) return; var t = $("tok").value.trim(); gh();
    if (t) { if (!/^(github_pat_|ghp_)[A-Za-z0-9_]{20,}$/.test(t)) { toast("شكل الرمز غير صحيح", true); return; } S.t = t; await persist(); $("tok").value = ""; ghTxt(); toast("تم حفظ الرمز مشفّراً ✓"); loadCfg(true); }
    else toast("تم حفظ إعدادات المستودع");
  }
  async function changePw() {
    if (!S) return; var p0 = $("pw0").value, p1 = $("pw1").value, p2 = $("pw2").value;
    if (p1.length < 10) { toast("كلمة السر الجديدة قصيرة (10 أحرف على الأقل)", true); return; }
    if (p1 !== p2) { toast("التأكيد لا يطابق كلمة السر الجديدة", true); return; }
    try { await openAny(USER, p0, lsv()); } catch (e) { toast("كلمة السر الحالية غير صحيحة", true); return; }
    PASS = USER + "|" + normPw(p1); await persist(); $("pw0").value = $("pw1").value = $("pw2").value = ""; toast("تم تغيير كلمة السر ✓ احذف vault.json من المستودع الآن");
  }
  function backup() { var v = lsv(); if (!v) { toast("لا توجد نسخة محفوظة", true); return; } var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(v, null, 2)], { type: "application/json" })); a.download = "hds-vault-backup.json"; a.click(); }
  async function delVault() {
    if (!S || !S.t) { go("sec"); toast("أضف رمز GitHub أولاً", true); return; }
    if (!window.confirm("سيُحذف vault.json من المستودع. هل نزّلت نسخة احتياطية؟")) return;
    try {
      var g = gh(), url = api(g, "vault.json"), r = await fetch(url + "?ref=" + encodeURIComponent(g.b) + "&t=" + Date.now(), { headers: hdr(false), cache: "no-store" });
      if (r.status === 404) { toast("الملف غير موجود في المستودع (محذوف مسبقاً)"); return; }
      if (!r.ok) throw new Error("تعذّر الوصول (" + r.status + ")");
      var sha = (await r.json()).sha, d = await fetch(url, { method: "DELETE", headers: hdr(true), body: JSON.stringify({ message: "حذف الملف المشفّر", sha: sha, branch: g.b }) });
      if (!d.ok) throw new Error("فشل الحذف (" + d.status + ")"); toast("تم حذف vault.json من المستودع ✓");
    } catch (e) { toast(e.message || "فشل الحذف", true); }
  }

  /* ---------- liaison ---------- */
  $("lgGo").addEventListener("click", login);
  [$("lgUser"), $("lgPass")].forEach(function (el) { el.addEventListener("keydown", function (e) { if (e.key === "Enter") login(); }); });
  $("lockBtn").addEventListener("click", lock);
  $("save").addEventListener("click", save); $("load").addEventListener("click", function () { loadCfg(false); }); $("dl").addEventListener("click", download);
  $("dAdd").addEventListener("click", addDev); $("tokSave").addEventListener("click", saveToken); $("pwSave").addEventListener("click", changePw); $("bkDl").addEventListener("click", backup); $("vDel").addEventListener("click", delVault);
  ["pointerdown", "keydown"].forEach(function (ev) { document.addEventListener(ev, function () { if (S) idle(); }, true); });
  document.addEventListener("visibilitychange", function () { if (document.hidden) hiddenAt = Date.now(); else if (S && hiddenAt && Date.now() - hiddenAt > 5 * 60000) { lock(); lgErr("أُغلقت الجلسة بعد غياب طويل"); } });
  window.addEventListener("beforeunload", function (e) { if (dirty) { e.preventDefault(); e.returnValue = ""; } });
  $("dim").addEventListener("input", function () { $("dimV").textContent = $("dim").value; });
  $("lgUser").value = "HDS";
})();

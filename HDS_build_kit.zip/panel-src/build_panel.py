import hashlib, base64, re
css=open('/tmp/w/panel/style.css',encoding='utf-8').read()
body=open('/tmp/w/panel/body.html',encoding='utf-8').read()
js=open('/tmp/w/panel/panel.js',encoding='utf-8').read()
def h(t): return "'sha256-"+base64.b64encode(hashlib.sha256(t.encode('utf-8')).digest()).decode()+"'"
csp=("default-src 'none'; script-src %s; style-src %s; connect-src 'self' https://api.github.com; img-src data: blob:; base-uri 'none'; form-action 'none'"%(h(js),h(css)))
html='<!DOCTYPE html>\n<html lang="ar" dir="rtl">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<meta http-equiv="Content-Security-Policy" content="%s">\n<meta name="robots" content="noindex,nofollow">\n<title>لوحة تحكم HDS</title>\n<style>%s</style>\n</head>\n<body>\n%s\n<script>%s</script>\n</body>\n</html>\n'%(csp,css,body,js)
open('/mnt/user-data/outputs/panel2/index.html','w',encoding='utf-8').write(html)
print(len(html))

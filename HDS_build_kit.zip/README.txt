HDS build kit
key.pem + cert.pem : cle de signature de l'application. A garder secrete. Sans elle, une nouvelle version ne s'installe pas sur l'ancienne.
build.py : reconstruit et signe l'APK (ROOT = dossier decompresse, ARM64=1 ou ARM32=1 pour les variantes). verify_apk.py : verifie les signatures.
prune.py / csspurge.py : nettoyage. panel-src : sources du panneau (build_panel.py genere index.html).
Release : app.js, remote-keys.js et app.css sont minifies avec esbuild avant le build (ne pas minifier i18n.js, kids-extra.js, titounis.js : ils grossissent).

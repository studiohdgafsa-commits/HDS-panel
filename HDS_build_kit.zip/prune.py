import re,glob
W='/tmp/a/assets/www/'
files=[W+f for f in ['app.js','kids-extra.js','titounis.js','remote-keys.js','index.html','i18n.js']]
others=[f for f in files if not f.endswith('app.js')]
other_txt=''.join(open(f,encoding='utf-8',errors='replace').read() for f in others)
L=open(W+'app.js',encoding='utf-8').read().split('\n')
removed=[]
def count(name,lines):
    pat=re.compile(r'(?<![\w$.])'+re.escape(name)+r'(?![\w$])')
    return len(pat.findall('\n'.join(lines)))+len(pat.findall(other_txt))
changed=True
while changed:
    changed=False
    i=0
    while i<len(L):
        l=L[i]
        m=re.match(r'^  function (\w+)\(',l)
        mv=re.match(r'^  var (\w+) = ',l) if not m else None
        name=(m or mv).group(1) if (m or mv) else None
        if name and count(name,L)==1:
            # find block end
            j=i
            if m:
                if re.search(r'\}\s*$',l) and l.count('{')==l.count('}'): j=i
                else:
                    j=i+1
                    while j<len(L) and L[j]!='  }': j+=1
            else:
                bal=sum(l.count(c) for c in '[({')-sum(l.count(c) for c in '])}')
                if bal==0 and l.rstrip().endswith(';'): j=i
                else:
                    j=i+1
                    while j<len(L) and not re.match(r'^  [\]\}\)];?\s*$',L[j]) and not (L[j].startswith('  ]') or L[j].startswith('  }')): j+=1
            # also drop directly preceding doc comment lines
            k=i
            while k>0 and (L[k-1].strip().startswith('/**') or L[k-1].strip().startswith('//') or L[k-1].strip().startswith('*/')) : k-=1
            removed.append((name,k+1,j+1))
            del L[k:j+1]; changed=True; continue
        i+=1
open(W+'app.js','w',encoding='utf-8').write('\n'.join(L))
print(len(removed),'removed'); print([r[0] for r in removed])

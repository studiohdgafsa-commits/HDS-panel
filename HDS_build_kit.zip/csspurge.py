import re
W='/tmp/a/assets/www/'
def toks(t): return set(re.findall(r'[A-Za-z_][\w-]*',t))
before=toks(open('/tmp/w/app.before_prune.js',encoding='utf-8',errors='replace').read())
now=set()
for f in ['app.js','kids-extra.js','titounis.js','remote-keys.js','index.html','i18n.js']:
    now|=toks(open(W+f,encoding='utf-8',errors='replace').read())
removed=before-now
css=open(W+'app.css',encoding='utf-8').read()
def split_sel(sel):
    out=[];d=0;cur=''
    for ch in sel:
        if ch in '([': d+=1
        elif ch in ')]': d-=1
        if ch==',' and d==0: out.append(cur);cur=''
        else: cur+=ch
    out.append(cur); return out
cls=re.compile(r'\.([A-Za-z_][\w-]*)')
dropped=[0,0]
def process(src):
    res=[];i=0;n=len(src)
    while i<n:
        # copy whitespace/comments
        m=re.match(r'\s+|/\*.*?\*/',src[i:],re.S)
        if m: res.append(m.group(0)); i+=len(m.group(0)); continue
        # find end of prelude
        j=i;d=0;q=None
        while j<n:
            ch=src[j]
            if q:
                if ch==q and src[j-1]!='\\': q=None
            elif ch in '"\'': q=ch
            elif ch=='{' or ch==';': break
            j+=1
        prelude=src[i:j]
        if j>=n: res.append(src[i:]); break
        if src[j]==';': res.append(src[i:j+1]); i=j+1; continue
        # block
        k=j+1;d=1;q=None
        while k<n and d>0:
            ch=src[k]
            if q:
                if ch==q and src[k-1]!='\\': q=None
            elif ch in '"\'': q=ch
            elif ch=='{': d+=1
            elif ch=='}': d-=1
            k+=1
        body=src[j+1:k-1]
        p=prelude.strip()
        if p.startswith('@media') or p.startswith('@supports'):
            nb=process(body)
            if nb.strip()=='' : dropped[0]+=1
            else: res.append(prelude+'{'+nb+'}')
        elif p.startswith('@'):
            res.append(prelude+'{'+body+'}')
        else:
            sels=split_sel(prelude)
            keep=[s for s in sels if not any(c in removed for c in cls.findall(s))]
            if not keep: dropped[0]+=1
            else:
                if len(keep)<len(sels): dropped[1]+=1
                res.append(','.join(keep)+'{'+body+'}')
        i=k
    return ''.join(res)
new=process(css)
open(W+'app.css','w',encoding='utf-8').write(new)
print('rules dropped',dropped,'size',len(css),'->',len(new),'removed tokens',len(removed))

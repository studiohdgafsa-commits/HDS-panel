import sys, struct, hashlib, zipfile, base64, io
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography import x509
path=sys.argv[1]
d=open(path,'rb').read()
print('size',len(d),'sha256',hashlib.sha256(d).hexdigest())
# --- zip structure
z=zipfile.ZipFile(path); print('testzip:',z.testzip(),'entries',len(z.namelist()))
names=z.namelist(); print('dups:',len(names)-len(set(names)))
eocd=d.rfind(b'PK\x05\x06'); cd_size,cd_off=struct.unpack('<II',d[eocd+12:eocd+20]); print('eocd',eocd,'cd_off',cd_off,'cd_size',cd_size)
# --- alignment of stored entries
bad=[]
for i in z.infolist():
    if i.compress_type==0:
        off=i.header_offset+30+len(i.filename.encode())+len(i.extra)
        al=4096 if i.filename.endswith('.so') else 4
        if off%al: bad.append((i.filename,off%al))
print('misaligned stored:',bad[:5])
for n in ('resources.arsc','AndroidManifest.xml','classes.dex'):
    i=z.getinfo(n); print(n,'method',i.compress_type)
# --- APK signing block
magic=d.rfind(b'APK Sig Block 42',0,cd_off); assert magic>0
blk_size=struct.unpack('<Q',d[cd_off-24:cd_off-16])[0]; start=cd_off-blk_size-8
sz0=struct.unpack('<Q',d[start:start+8])[0]; print('sig block size ok:',sz0==blk_size, 'start',start)
pos=start+8; end=cd_off-24; v2=None
while pos<end:
    ln=struct.unpack('<Q',d[pos:pos+8])[0]; idv=struct.unpack('<I',d[pos+8:pos+12])[0]
    if idv==0x7109871a: v2=d[pos+12:pos+8+ln]
    pos+=8+ln
print('v2 found:',v2 is not None)
def rd(b,o): n=struct.unpack('<I',b[o:o+4])[0]; return b[o+4:o+4+n],o+4+n
signers,_=rd(v2,0); signer,_=rd(signers,0)
signed,o=rd(signer,0); sigs,o=rd(signer,o); pub,o=rd(signer,o)
digs,p=rd(signed,0); certs,p=rd(signed,p)
dg,_=rd(digs,0); algo=struct.unpack('<I',dg[:4])[0]; digest,_=rd(dg,4)
cert_der,_=rd(certs,0)
sg,_=rd(sigs,0); salgo=struct.unpack('<I',sg[:4])[0]; sig,_=rd(sg,4)
print('algos',hex(algo),hex(salgo))
# recompute digest
s1=d[:start]; s2=d[cd_off:eocd]; s3=bytearray(d[eocd:]); struct.pack_into('<I',s3,16,start)
ch=[]
for sec in (s1,bytes(s2),bytes(s3)):
    for i in range(0,len(sec),1<<20):
        c=sec[i:i+(1<<20)]; ch.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(c))+c).digest())
top=hashlib.sha256(b'\x5a'+struct.pack('<I',len(ch))+b''.join(ch)).digest()
print('v2 digest matches:',top==digest)
cert=x509.load_der_x509_certificate(cert_der)
try:
    cert.public_key().verify(sig,signed,padding.PKCS1v15(),hashes.SHA256()); print('v2 signature valid: True')
except Exception as e: print('v2 signature valid: False',e)
# --- v1
mf=z.read('META-INF/MANIFEST.MF'); sf=z.read('META-INF/CERT.SF')
import re
secs=mf.split(b'\r\n\r\n')[1:-1]
ok=0;badf=[]
for s in secs:
    s=s.replace(b'\r\n ',b''); m=re.search(rb'Name: (.*)\r\nSHA-256-Digest: (.*)',s)
    if not m: continue
    nm=m.group(1).decode(); dig=base64.b64decode(m.group(2))
    if hashlib.sha256(z.read(nm)).digest()==dig: ok+=1
    else: badf.append(nm)
real=[n for n in names if not n.endswith('/') and not n.startswith('META-INF/CERT') and n!='META-INF/MANIFEST.MF']
print('v1 manifest entries ok',ok,'of',len(real),'bad',badf[:3])
print('SF manifest digest ok:',base64.b64encode(hashlib.sha256(mf).digest()) in sf)
